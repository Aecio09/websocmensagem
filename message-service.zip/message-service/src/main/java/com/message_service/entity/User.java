package com.message_service.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "tb_user")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(nullable = false, unique = true)
    private String username;
    @Column(nullable = false)
    private String password;

    @Column(columnDefinition = "TEXT", nullable = true)
    private String publicKey;

    @OneToMany(mappedBy = "senderBy", cascade = CascadeType.ALL, orphanRemoval = true)
    @Column(nullable = true)
    private List<Message> messages = new ArrayList<>();

    @ElementCollection
    @Column(nullable = true)
    private Set<Long> friendsIds = new HashSet<>();

    @ElementCollection
    @Column(nullable = true)
    private Set<Long> friendRequestsIds = new HashSet<>();

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "tb_user_role",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id")
    )
    private Set<Role> roles = new HashSet<>();

}
