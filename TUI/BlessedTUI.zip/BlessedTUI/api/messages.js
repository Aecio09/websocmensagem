import { api } from './client.js';

export async function getMessages() {
  const res = await api.get('/messages');
  return res.data;
}

export async function getMessagesWith(userId) {
  const res = await api.get(`/messages/${userId}`);
  return res.data;
}
