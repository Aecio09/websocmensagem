import blessed from 'blessed';
import { connectChat } from '../socket/chat.js';
import { findUserByUsername } from '../api/users.js';
import { getMessagesWith } from '../api/messages.js';
import { menuScreen } from './menu.js';

export function chatScreen(screen, token) {
  // Tela de pesquisa de usuário
  searchUserScreen(screen, token);
}

function searchUserScreen(screen, token) {
  const box = blessed.box({
    parent: screen,
    width: 50,
    height: 10,
    top: 'center',
    left: 'center',
    border: 'line',
    label: ' Pesquisar Usuário '
  });

  const searchInput = blessed.textbox({
    parent: box,
    top: 1,
    left: 2,
    width: '90%',
    height: 3,
    border: 'line',
    label: 'Username',
    inputOnFocus: true
  });

  const msg = blessed.text({
    parent: box,
    bottom: 1,
    left: 2,
    fg: 'yellow'
  });

  searchInput.on('submit', async () => {
    const username = searchInput.getValue().trim();
    if (!username) {
      msg.setContent('Digite um username');
      screen.render();
      searchInput.focus();
      return;
    }

    try {
      msg.setContent('Buscando...');
      screen.render();
      
      const user = await findUserByUsername(username);
      box.destroy();
      openChatWithUser(screen, token, user);
    } catch (err) {
      msg.setContent('Usuário não encontrado');
      screen.render();
      searchInput.clearValue();
      searchInput.focus();
    }
  });

  // ESC para voltar ao menu
  screen.key(['escape'], () => {
    box.destroy();
    menuScreen(screen, token);
  });

  searchInput.focus();
  screen.render();
}

function openChatWithUser(screen, token, targetUser) {
  const messages = blessed.log({
    parent: screen,
    top: 0,
    left: 0,
    width: '100%',
    height: '90%',
    border: 'line',
    label: ` Chat com ${targetUser.username} - Conectando... [ESC] Voltar `,
    scrollable: true,
    tags: true
  });

  const input = blessed.textbox({
    parent: screen,
    bottom: 0,
    height: 3,
    width: '100%',
    border: 'line',
    inputOnFocus: true
  });

  let ws = null;

  // Carrega mensagens anteriores
  async function loadPreviousMessages() {
    try {
      const history = await getMessagesWith(targetUser.id);
      if (history && history.length > 0) {
        history.forEach(msg => {
          const sender = msg.senderUsername || msg.sender || 'Desconhecido';
          const content = msg.messageContent || msg.content || '';
          messages.log(`${sender}: ${content}`);
        });
        screen.render();
      }
    } catch (err) {
      // Silenciosamente ignora se não conseguir carregar histórico
    }
  }

  loadPreviousMessages();

  ws = connectChat(
    token, 
    // onMessage
    msg => {
      
      // Tenta diferentes formatos de campo
      const sender = msg.senderUsername || msg.sender || msg.user || 'Desconhecido';
      const content = msg.messageContent || msg.content || msg.message || '';
      
      messages.log(`${sender}: ${content}`);
      screen.render();
    },
    // onConnect
    () => {
      messages.setLabel(` Chat com ${targetUser.username} - Conectado [ESC] Voltar `);
      messages.log('{green-fg}Conectado ao servidor!{/green-fg}');
      screen.render();
    },
    // onError
    (err) => {
      messages.log(`{red-fg}Erro: ${err}{/red-fg}`);
      screen.render();
    }
  );

  // ESC para voltar ao menu
  screen.key(['escape'], () => {
    if (ws) ws.disconnect();
    messages.destroy();
    input.destroy();
    menuScreen(screen, token);
  });

  input.on('submit', () => {
    const content = input.getValue();
    if (content.trim()) {
      if (ws.send(targetUser.id, content)) {
        messages.log(`Você: ${content}`);
      } else {
        messages.log('{red-fg}Aguarde a conexão...{/red-fg}');
      }
    }
    input.clearValue();
    input.focus();
    screen.render();
  });

  input.focus();
  screen.render();
}
