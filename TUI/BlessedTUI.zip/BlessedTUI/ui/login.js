import blessed from 'blessed';
import { login } from '../api/auth.js';
import { setToken } from '../api/client.js';
import { menuScreen } from './menu.js';

export function loginScreen(screen) {
  const box = blessed.form({
    parent: screen,
    width: 50,
    height: 12,
    top: 'center',
    left: 'center',
    border: 'line',
    label: ' Login ',
    keys: true
  });

  const user = blessed.textbox({
    parent: box,
    top: 1,
    left: 2,
    width: '90%',
    height: 3,
    label: 'Username',
    border: 'line',
    inputOnFocus: true
  });

  const pass = blessed.textbox({
    parent: box,
    top: 5,
    left: 2,
    width: '90%',
    height: 3,
    secret: true,
    label: 'Password',
    border: 'line',
    inputOnFocus: true
  });

  const msg = blessed.text({
    parent: box,
    bottom: 1,
    left: 2,
    fg: 'red'
  });

  // Quando terminar de digitar username, vai para password
  user.on('submit', () => {
    pass.focus();
  });

  // Quando terminar de digitar password, faz o login
  pass.on('submit', async () => {
    try {
      const username = user.getValue();
      const password = pass.getValue();
      
      if (!username || !password) {
        msg.setContent('Preencha todos os campos');
        screen.render();
        return;
      }
      
      const token = await login(username, password);
      setToken(token);
      box.destroy();
      menuScreen(screen, token);
    } catch (err) {
      // Mostrar erro mais detalhado para debug
      msg.setContent(`Erro: ${err.message || 'Login inválido'}`);
      screen.render();
    }
  });

  user.focus();
  screen.render();
}
